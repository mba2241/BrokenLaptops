'''
Created on Oct 1, 2020

@author: mamadouba
'''
from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
import os


# install using,  pip3 install sqlalchemy flask-sqlalchemy 
from flask_sqlalchemy import SQLAlchemy


database = ('mysql + pymysql://{name}:{password}@/{dbname}? unix_socket=/cloudsql/{connection}').format(
    
    name        = os.environ ['DB_USERR'],
    password    = os.environ ['DB_PASS'],
    dbname      = os.environ ['DB_NAME'],
    connection  = os.environ ['DB_CONNECTION_NAME'],
    )


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = database

db = SQLAlchemy(app)

##################################################
# use python shell to create the database (from inside the project directory) 
# >>> from app import db
# >>> db.create_all()
# >>> exit()
###################################################
@app.route ('/init_db')
def init_db():
    db.drop_all ()
    db.create_all()
    return 'DB initialized'

@app.route ('/test')
def test():
    return 'APP is running'

@app.route ('/')
def index():
    BrokenLaptops = BrokenLaptop.query.all() 
    return render_template("index.html", BrokenLaptops=BrokenLaptops)


@app.route('/create', methods=['GET','POST'])
def create():
    if request.form:
        brand = request.form.get("brand")
        price = request.form.get("price")
        
        brokenlaptop = BrokenLaptop(brand=brand,price=price)
        db.session.add(brokenlaptop)
        db.session.commit()
        
    brokenlaptops = BrokenLaptop.query.all()
    return render_template("create.html",brokenlaptops=brokenlaptops)

@app.route('/delete/<laptop_id>') # add id
def delete(laptop_id):
    brokenlaptop = BrokenLaptop.query.get(laptop_id)
    db.session.delete(brokenlaptop)
    db.session.commit()
    
    brokenlaptops = BrokenLaptop.query.all()
    return render_template('delete.html', brokenlaptops=brokenlaptops )

@app.route('/update/<laptop_id>', methods=['GET','POST']) # add id 
def update(laptop_id):
    if request.form:
        newbrand = request.form.get('brand')
        newprice = request.form.get('price')
        
        brokenlaptop = BrokenLaptop.query.get(laptop_id)
        brokenlaptop.brand = newbrand
        brokenlaptop.price = newprice
        
        db.session.commit()
        return redirect("/")
    
    brokenlaptop = BrokenLaptop.query.get(laptop_id)
    return render_template('update.html', brokenlaptop = brokenlaptop, title = 'update')

class BrokenLaptop(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    brand = db.Column(db.String(40), nullable = False)
    price = db.Column(db.Float, nullable = True)
    

if __name__ == '__main__':
    app.run(debug=True)
